# Rent Accounts — Netlify Setup Guide

## What's in this folder

| File | Purpose |
|---|---|
| `index.html` | The app itself. |
| `manifest.json` | PWA manifest — name, colors, and icon list, used when someone installs the app to their home screen. |
| `sw.js` | Service worker. Caches the app shell so it loads offline and works as an installable app. |
| `xlsx.full.min.js` | The SheetJS library, used for the "Download Excel" export. Kept as its own file so `index.html` stays smaller. |
| `icon-16.png` … `icon-512.png` | App icon at every size iOS, Android, and browsers ask for. |
| `icon-001.png` | The original full-size logo you uploaded. |
| `favicon.ico` | Browser tab icon. |
| `apple-touch-icon.png` | iOS "Add to Home Screen" icon (180×180). |
| `netlify.toml` | Netlify config: publishes this folder as-is and sets a couple of security headers. |

## Deploy to Netlify

**Option A — drag and drop (fastest, no account setup needed for updates later)**
1. Go to [app.netlify.com/drop](https://app.netlify.com/drop).
2. Drag the *contents* of this folder (not a parent folder, and not the zip itself — unzip first) onto the page.
3. Netlify gives you a live URL in a few seconds, e.g. `random-name-123.netlify.app`.
4. To update later, make your edits and drag the folder in again.

**Option B — connect to Git (if you want auto-deploys on every push)**
1. Put these files in a Git repo (GitHub/GitLab/Bitbucket).
2. In Netlify: **Add new site → Import an existing project**, pick the repo.
3. Build command: leave blank. Publish directory: `.` (the repo root, since `netlify.toml` already sets `publish = "."`).
4. Deploy.

## Rename the site (optional)
In Netlify: **Site settings → Change site name** to get a nicer URL like `rent-accounts.netlify.app` instead of the random one. A custom domain can be added from the same **Domain settings** page.

## Things to check after deploying
- Open the live URL, confirm the app loads and the icon shows correctly in the browser tab.
- On your phone, open the URL in the browser and use "Add to Home Screen" (iOS Safari) or the install prompt (Android Chrome) — the icon and name should match what's in `manifest.json`.
- Make a small test entry, refresh the page, and confirm it's still there — this checks that local storage/IndexedDB is working as expected on the live domain (browser storage is per-domain, so data won't carry over from `file://` testing).
- Turn on airplane mode after the first successful load and reopen the app — it should still load from the service worker cache.

## Notes
- All data stays in the browser's local storage on the device that opens the app — nothing is sent to a server. Clearing browser data/cache on that device will remove it, so use "Download Excel" periodically as a backup.
- If you edit `index.html` later and redeploy, bump `CACHE_NAME` in `sw.js` (e.g. `rent-accounts-v1` → `rent-accounts-v2`) so returning visitors pick up the new version instead of a stale cached one.
